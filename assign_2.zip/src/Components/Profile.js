import React from "react";

class Profile extends React.Component {
  render() {
    return (
      <div className="container">
        <h1>Profile</h1>
      </div>
    );
  }
}

export default Profile;
