import React, { Component } from "react";

class Contact extends React.Component {

    constructor(){
        super()
            this.state={
                title: 'Java',
                detail: 'Something'
            }

            this.handleChangeTitle = this.handleChangeTitle.bind(this)
            this.handleChangeDetail = this.handleChangeTitle.bind(this)
            this.handleSubmit = this.handleSubmit.bind(this)
    }

    handleChangeTitle(event){
     this.setState({title:event.target.value})
    }

    handleChangeDetail(event){
        this.setState({detail:event.target.value})
       }

    handleSubmit = () => {
        console.log(this.setState)
    }   

  render() {
    return (
      <>
        <div className="container">
          <h3>Contact</h3>

          <div className="mb-3">
            <label  className="form-label">
              Email address
            </label>
            <input
              type="text"
              id="title"
              className="form-control"
              value={this.state.title}
              onChange={this.handleChangeTitle}
            />
          </div>
          <div className="mb-3">
            <label  className="form-label">
              Password
            </label>
            <input
              type="text"
              id="detail"
              className="form-control"
              value={this.state.detail}
              onChange={this.handleChangeDetail}
            />
          </div>
          <div className="mb-3 form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="exampleCheck1"
            />
            <label className="form-check-label">
              Check me out
            </label>
          </div>
          <button 
          className="btn btn-primary"
          onClick={this.handleSubmit}
          >
            Submit
          </button>
        </div>
      </>
    );
  }
}

export default Contact;
